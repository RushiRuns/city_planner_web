<?php
$pageTitle  = 'Service Stations Management';
$activePage = 'stations';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/rbac.php';
require_once __DIR__ . '/includes/audit.php';
startSecureSession(); requireLogin(); requirePermission('stations.view');

$db = getDB();
$admin = getSessionAdmin();
$csrfToken = generateCsrfToken();
$serviceFilter = $_GET['service'] ?? '';

// Handle Create Station POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_station'])) {
    requireRole('super_admin');
    if (validateCsrf()) {
        $stnId = trim($_POST['station_id']);
        $serviceId = trim($_POST['service_id']);
        $serviceLabel = trim($_POST['service_label']);
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $city = trim($_POST['city']);

        if ($stnId && $name && $email) {
            $stmt = $db->prepare("INSERT INTO service_stations (station_id, service_id, service_label, name, email, phone, city) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param('sssssss', $stnId, $serviceId, $serviceLabel, $name, $email, $phone, $city);
            if ($stmt->execute()) {
                logAudit('create_station', 'station', $stnId, '', "name:$name service:$serviceLabel");
                $successMsg = "Station created successfully.";
            } else {
                $errorMsg = "Error creating station: " . $db->error;
            }
        }
    }
}

// Fetch Stations with scope enforcement
$where = " WHERE 1=1 ";
$where .= getStationScopeWhere('ss');
if ($serviceFilter) {
    // If filtering by service, verify admin is allowed to access this service
    if ($admin['role'] === 'super_admin' || isAdminAllowedCategory($serviceFilter, $admin)) {
        $where .= " AND ss.service_id = '" . $db->real_escape_string($serviceFilter) . "'";
    } else {
        $where .= " AND 1=0";
    }
}
$stationsQ = $db->query("SELECT ss.*, 
    (SELECT COUNT(*) FROM employees WHERE station_id = ss.station_id) AS staff_count
    FROM service_stations ss $where ORDER BY ss.service_label, ss.name ASC");

$stations = [];
if ($stationsQ) {
    while ($st = $stationsQ->fetch_assoc()) {
        $stations[] = $st;
    }
}

require_once __DIR__ . '/includes/layout.php';
?>

<div class="page-header">
    <div>
        <div class="page-back-wrapper">
            <a href="javascript:history.back()" onclick="if(window.history.length > 1 && document.referrer && document.referrer.indexOf(window.location.host) !== -1){ window.history.back(); return false; } else { window.location.href='<?= BASE_URL ?>dashboard.php'; return false; }" class="btn-back">
                <i class="bi bi-arrow-left"></i> Back
            </a>
        </div>
        <h1 class="page-title"><i class="bi bi-geo-alt-fill text-critical"></i> Service Stations</h1>
        <p class="page-subtitle">Municipal and emergency responder stations</p>
    </div>
    <div class="page-actions">
        <?php if ($admin['role'] === 'super_admin'): ?>
        <button class="btn btn-primary btn-sm" onclick="Modal.open('newStationModal')">
            <i class="bi bi-plus-circle-fill"></i> Add New Station
        </button>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($successMsg)): ?>
<div class="alert alert-success mb-4"><?= htmlspecialchars($successMsg) ?></div>
<?php endif; ?>
<?php if (!empty($errorMsg)): ?>
<div class="alert alert-critical mb-4"><?= htmlspecialchars($errorMsg) ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-wrapper" style="border:none;border-radius:0;">
        <table class="table">
            <thead>
                <tr>
                    <th>Station ID</th>
                    <th>Station Name</th>
                    <th>Service Category</th>
                    <th>City / Zone</th>
                    <th>Contact Phone</th>
                    <th>Staff Count</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($stations)): ?>
                <tr>
                    <td colspan="7">
                        <div class="empty-state">
                            <div class="empty-state-icon">🏢</div>
                            <div class="empty-state-title">No Stations Found</div>
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($stations as $st): ?>
                <tr>
                    <td><code class="mono"><?= htmlspecialchars($st['station_id']) ?></code></td>
                    <td><strong><?= htmlspecialchars($st['name']) ?></strong></td>
                    <td><span class="badge badge-info"><?= htmlspecialchars($st['service_label']) ?></span></td>
                    <td><i class="bi bi-pin-map-fill text-muted me-1"></i><?= htmlspecialchars($st['city']) ?></td>
                    <td><?= htmlspecialchars($st['phone']) ?></td>
                    <td><span class="badge badge-success"><?= (int)$st['staff_count'] ?> Active Staff</span></td>
                    <td>
                        <a href="<?= BASE_URL ?>employees.php?station=<?= urlencode($st['station_id']) ?>" class="btn btn-surface btn-sm" title="View Staff">
                            <i class="bi bi-people-fill"></i> Staff
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: New Station -->
<div class="modal-backdrop" id="newStationModal">
    <div class="modal">
        <form method="POST" action="">
            <input type="hidden" name="<?= CSRF_TOKEN_NAME ?>" value="<?= htmlspecialchars($csrfToken) ?>">
            <input type="hidden" name="create_station" value="1">
            <div class="modal-header">
                <span class="modal-title"><i class="bi bi-plus-circle-fill text-primary"></i> Register Service Station</span>
                <button type="button" class="modal-close" onclick="Modal.close('newStationModal')"><i class="bi bi-x"></i></button>
            </div>
            <div class="modal-body">
                <div class="form-group mb-3">
                    <label class="form-label">Station ID (e.g. STN-FIRE-01)</label>
                    <input type="text" name="station_id" class="form-control" placeholder="STN-FIRE-01" required>
                </div>
                <div class="form-group mb-3">
                    <label class="form-label">Station Name</label>
                    <input type="text" name="name" class="form-control" placeholder="Central Fire Station" required>
                </div>
                <div class="grid grid-cols-2 gap-3 mb-3">
                    <div class="form-group">
                        <label class="form-label">Service Key</label>
                        <select name="service_id" class="form-control" required onchange="document.getElementById('service_label_input').value = this.options[this.selectedIndex].text;">
                            <?php 
                            $dbServices = getDbServices();
                            $firstLabel = '';
                            foreach ($dbServices as $k => $c): 
                                if (empty($firstLabel)) $firstLabel = $c['service_name'];
                            ?>
                            <option value="<?= $k ?>"><?= htmlspecialchars($c['service_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Service Label</label>
                        <input type="text" id="service_label_input" name="service_label" class="form-control" value="<?= htmlspecialchars($firstLabel ?: 'Service Station') ?>" required>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-3 mb-3">
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="station@city.gov" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" class="form-control" placeholder="101" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">City / Area Zone</label>
                    <input type="text" name="city" class="form-control" placeholder="Central Pune, Zone 1" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="Modal.close('newStationModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Create Station</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>
